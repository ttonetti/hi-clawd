# Onboarding para personas nuevas en Claude (demo)

Prototipo interactivo de un onboarding para personas que nunca han usado IA, dentro de una interfaz inspirada en Claude. No es la app oficial de Claude.

La guía es **Lumi**, un personaje que acompaña a la persona mientras aprende a trabajar con **Claude**, la IA. La demo deja clara esa separación: Lumi explica y guía; Claude es quien responde en el chat y genera los resultados.

## Qué incluye

- **Bienvenida** con preferencias de comodidad: letra más grande, ir más despacio y hablar en lugar de escribir.
- **Aprender haciendo**: primer resultado, pedir un cambio, contar un poco de ti y guardarlo en un proyecto.
- **Artefactos con diagramas** cuando ayudan a entender algo.
- **«Tu mes con Claude»**: 13 retos cortos repartidos en cuatro semanas, sin rachas ni penalizaciones, con opción de pausa.
- **Cursos de Claude Academy** que se desbloquean según el progreso, con práctica personalizada.
- Español e inglés, con detección automática del idioma del navegador.

## Cómo abrirla

Abre `index.html` en cualquier navegador. No necesita instalación.

Para publicarla en internet, activa GitHub Pages en *Settings → Pages* con la rama `main` y la carpeta raíz.

## Limitaciones

- **Respuestas de Claude en directo**: solo funcionan cuando la demo se abre como artefacto dentro de claude.ai. Fuera de ahí se muestran respuestas de ejemplo, y la propia demo lo indica al pie.
- **Dictado por voz**: depende del navegador; funciona mejor en Chrome.
- **Nada se guarda**: al recargar, la demo vuelve a empezar.

## Versiones

| Archivo | Qué es |
| --- | --- |
| `index.html` | Versión actual (v6): Lumi como guía, estilo de marca de Anthropic, programa de un mes |
| `versiones/v2-estilo-anthropic.html` | v2 con el estilo de Anthropic, antes de separar a Lumi y Claude |
| `versiones/v1-onboarding.html` | Primera versión del onboarding |
